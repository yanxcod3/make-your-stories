self.addEventListener('install', () => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(clients.claim());
});

self.addEventListener('push', (event) => {

  let data = {};
  try {
    data = event.data ? JSON.parse(event.data.text()) : {};
  } catch (e) {
    console.warn('[SW] Invalid JSON, using fallback');
    data = { title: 'New Notification', body: event.data?.text() || 'You have a new message' };
  }

  const title = data.title || 'Notification';
  const options = {
    body: data.body || data.options?.body || 'Notification received',
    icon: '/images/logo.png',
    badge: '/images/logo.png',
    data: data.data || {}
  };

  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = event.notification.data?.url || '/';

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientsArr) => {
      const client = clientsArr.find(c => c.url.includes(url) && 'focus' in c);
      return client ? client.focus() : clients.openWindow(url);
    })
  );
});

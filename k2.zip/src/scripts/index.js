// CSS imports
import '../styles/styles.css';

import App from './pages/app';
import { initPushToggle } from './data/push';

document.addEventListener('DOMContentLoaded', async () => {
  const app = new App({
    content: document.querySelector('#main-content'),
    drawerButton: document.querySelector('#drawer-button'),
    navigationDrawer: document.querySelector('#navigation-drawer'),
  });

  const performPageTransition = async () => {
    if (document.startViewTransition) {
      document.startViewTransition(() => {
        app.renderPage();
      });
    } else {
      await app.renderPage();
    }
  };

  await performPageTransition();

  window.addEventListener('hashchange', async () => {
    await performPageTransition();
  });

  // Initialize push toggle UI; module will register service worker as needed
  try {
    // initPushToggle returns an object containing refresh method; we don't strictly need it here
    await initPushToggle('push-toggle');
  } catch (err) {
    // swallow errors, push is optional
    // console.error('Push init error', err);
  }
});
